# Vantera Roleplay

Svensk FiveM-community portal med:

- Discord-inloggning (via Supabase Auth)
- Ansökningsformulär som sparas i databas
- Staff-panel där behöriga kan godkänna / neka ansökningar
- Min portal för medlemmar

## Snabbstart

1. Läs **SETUP.md** (viktigt – Discord + Supabase måste konfigureras)
2. Kopiera `.env.example` till `.env` och fyll i nycklar
3. Kör SQL i `supabase-schema.sql` i din Supabase SQL Editor
4. `npm install && npm run dev`

## Viktiga sidor

| Sökväg | Beskrivning |
|--------|-------------|
| `/` | Startsida |
| `/ansokningar` | Kategorier |
| `/ansokningar/...` | Formulär |
| `/portal` | Min portal (inloggad) |
| `/staff` | Staff-panel (kräver staff-roll) |
| `/information` | Regler & info |

Se SETUP.md för hur du ger dig själv staff-roll efter första inloggningen.
