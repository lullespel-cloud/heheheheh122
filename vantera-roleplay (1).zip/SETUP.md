# Vantera Roleplay – Setup

Discord-inloggning + ansökningar + staff-panel + dokumentation via Supabase.

## Roller (exakt som ni kör)

| Roll | Ansökningar | Dokumentation | Redigera regler/prislista |
|------|-------------|----------------|---------------------------|
| **Ägare** | Allt | Ja | **Ja** |
| **Delägare** | Allt | Ja | **Ja** |
| **Head Admin** | Allt | Ja | **Ja** |
| **Admin** | Allt | Ja | **Ja** |
| **Head Mod** | Staff, servervakt, jobb, banöverklagan… | Ja | Nej |
| **Mod** | Staff, servervakt, jobb, banöverklagan… | Ja | Nej |
| **Helper** | Banöverklagan | Ja | Nej |
| **Medlemskapsansvarig** | **Bara medlemskap** | Ja | Nej |
| **Krimansvarig** | **Bara kriminell** | Ja | Nej |
| **Donationsansvarig** | Banöverklagan + dokumentera donationer | Ja | Nej |

**Banöverklaganden:** alla staff-nivåer (helper → ägare) kan se och svara.

## 1. Supabase

1. Skapa projekt på https://supabase.com  
2. Project Settings → API → kopiera URL + anon key

## 2. `.env`

```env
VITE_SUPABASE_URL=https://DIN-PROJEKT.supabase.co
VITE_SUPABASE_ANON_KEY=din-anon-key
```

## 3. Discord i Supabase

1. Authentication → Providers → Discord → Enable  
2. Client ID + Client Secret från https://discord.com/developers/applications  
3. Redirect: den URL Supabase visar + `http://localhost:5173/portal` (+ din live-URL senare)  
4. Spara

## 4. SQL

Kör hela filen `supabase-schema.sql` i SQL Editor.

## 5. Ge roller efter första Discord-inloggning

```sql
-- Ägare
update profiles set roles = array['ägare','admin'] where discord_username = 'NAMN';

-- Delägare
update profiles set roles = array['delägare','admin'] where discord_username = 'NAMN';

-- Head Admin
update profiles set roles = array['head admin','admin'] where discord_username = 'NAMN';

-- Admin
update profiles set roles = array['admin'] where discord_username = 'NAMN';

-- Head Mod
update profiles set roles = array['head mod','mod'] where discord_username = 'NAMN';

-- Mod
update profiles set roles = array['mod'] where discord_username = 'NAMN';

-- Helper
update profiles set roles = array['helper'] where discord_username = 'NAMN';

-- Medlemskapsansvarig (bara medlemsansökningar)
update profiles set roles = array['medlemskapsansvarig'] where discord_username = 'NAMN';

-- Krimansvarig (bara krimansökningar)
update profiles set roles = array['krimansvarig'] where discord_username = 'NAMN';

-- Donationsansvarig
update profiles set roles = array['donationsansvarig'] where discord_username = 'NAMN';

-- Vanlig medlem + krim-roll
update profiles set roles = array['medlem','kriminell'], status = 'Medlem'
where discord_username = 'NAMN';
```

## 6. Starta

```bash
npm install
npm run dev
```

| Sida | Vad |
|------|-----|
| `/` | Startsida |
| `/ansokningar` | Formulär |
| `/portal` | Min portal |
| `/staff` | Hantera ansökningar (filtrerat per roll) |
| `/staff/dokumentation` | Ban / unban / donation / varning |

Behörigheter styrs i `src/lib/permissions.ts`.
