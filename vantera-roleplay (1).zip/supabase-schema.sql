-- Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  discord_id text,
  discord_username text,
  display_name text,
  avatar_url text,
  roles text[] default '{}',
  status text default 'Medlem',
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;

drop policy if exists "Public profiles are viewable by everyone" on public.profiles;
create policy "Public profiles are viewable by everyone"
  on public.profiles for select using (true);

drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);

-- Applications
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  form_slug text not null,
  title text not null,
  data jsonb default '{}',
  status text not null default 'pending' check (status in ('pending', 'approved', 'denied', 'closed')),
  staff_note text,
  handled_by uuid references public.profiles(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.applications enable row level security;

drop policy if exists "Users see own applications" on public.applications;
create policy "Users see own applications"
  on public.applications for select
  using (auth.uid() = user_id);

drop policy if exists "Staff can read all applications" on public.applications;
create policy "Staff can read all applications"
  on public.applications for select
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
      and p.roles && array[
        'helper','mod','servervakt','staff','medlemskapsansvarig',
        'admin','ägare','delägare','ledning','owner'
      ]
    )
  );

drop policy if exists "Users can insert own applications" on public.applications;
create policy "Users can insert own applications"
  on public.applications for insert
  with check (auth.uid() = user_id);

drop policy if exists "Staff can update applications" on public.applications;
create policy "Staff can update applications"
  on public.applications for update
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
      and p.roles && array[
        'helper','mod','servervakt','staff','medlemskapsansvarig',
        'admin','ägare','delägare','ledning','owner'
      ]
    )
  );

-- Staff documentation logs (bans, unbans, donations, etc.)
create table if not exists public.staff_logs (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id) on delete cascade,
  target_discord text,
  target_name text,
  doc_type text not null,
  title text not null,
  body text not null,
  amount numeric,
  created_at timestamptz default now()
);

alter table public.staff_logs enable row level security;

drop policy if exists "Staff can read logs" on public.staff_logs;
create policy "Staff can read logs"
  on public.staff_logs for select
  using (
    exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
      and p.roles && array[
        'helper','mod','servervakt','staff','medlemskapsansvarig',
        'admin','ägare','delägare','ledning','owner'
      ]
    )
  );

drop policy if exists "Staff can insert logs" on public.staff_logs;
create policy "Staff can insert logs"
  on public.staff_logs for insert
  with check (
    auth.uid() = created_by
    and exists (
      select 1 from public.profiles p
      where p.id = auth.uid()
      and p.roles && array[
        'helper','mod','servervakt','staff','medlemskapsansvarig',
        'admin','ägare','delägare','ledning','owner'
      ]
    )
  );

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, discord_id, discord_username, display_name, avatar_url)
  values (
    new.id,
    new.raw_user_meta_data->>'provider_id',
    coalesce(new.raw_user_meta_data->>'preferred_username', new.raw_user_meta_data->>'full_name'),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do update set
    discord_id = excluded.discord_id,
    discord_username = excluded.discord_username,
    display_name = excluded.display_name,
    avatar_url = excluded.avatar_url;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
