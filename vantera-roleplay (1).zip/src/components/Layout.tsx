import { Link } from "@tanstack/react-router";
import { Bell, ChevronDown, LogOut, MessageCircle, Shield } from "lucide-react";
import type { ReactNode } from "react";
import { SITE_NAME, DISCORD_URL } from "@/lib/site";
import { useAuth } from "@/lib/auth";

const nav = [
  { to: "/", label: "Hem", exact: true },
  { to: "/ansokningar", label: "Ansökningar" },
  { to: "/information", label: "Information" },
  { to: "/portal", label: "Min portal" },
] as const;

export function Layout({ children }: { children: ReactNode }) {
  const { user, profile, loading, isStaff, signInWithDiscord, signOut } = useAuth();

  const displayName =
    profile?.display_name ||
    profile?.discord_username ||
    user?.user_metadata?.full_name ||
    user?.user_metadata?.name ||
    user?.user_metadata?.preferred_username ||
    "Användare";

  const avatar =
    profile?.avatar_url ||
    user?.user_metadata?.avatar_url ||
    user?.user_metadata?.picture;

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-violet-950 via-background to-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col px-4 pt-4">
        <header className="glass flex items-center gap-2 rounded-lg p-3">
          <nav className="grid flex-1 grid-cols-4 gap-1 text-sm font-semibold">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                activeOptions={{ exact: "exact" in n }}
                className="rounded-md px-3 py-2 transition-colors hover:bg-accent"
                activeProps={{ className: "bg-accent" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          {isStaff && (
            <Link
              to="/staff/dokumentation"
              className="hidden items-center gap-1 rounded-md border border-violet-500/40 bg-violet-500/10 px-2 py-2 text-xs font-semibold text-violet-200 sm:flex"
            >
              Docs
            </Link>
          )}
          {isStaff && (
            <Link
              to="/staff"
              className="hidden items-center gap-1 rounded-md border border-violet-500/40 bg-violet-500/10 px-3 py-2 text-xs font-semibold text-violet-200 sm:flex"
            >
              <Shield className="h-3.5 w-3.5" /> Staff
            </Link>
          )}

          <button aria-label="Notiser" className="hidden rounded-md border p-2 sm:block">
            <Bell className="h-4 w-4" />
          </button>

          {loading ? (
            <div className="hidden h-9 w-24 animate-pulse rounded-md bg-muted sm:block" />
          ) : user ? (
            <div className="hidden items-center gap-2 pl-2 sm:flex">
              {avatar ? (
                <img src={avatar} alt="" className="h-9 w-9 rounded-full object-cover" />
              ) : (
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-sm font-bold">
                  {displayName.slice(0, 1).toUpperCase()}
                </div>
              )}
              <div className="leading-tight">
                <div className="text-sm font-semibold">{displayName}</div>
                <span className="rounded border px-1.5 text-[10px] text-muted-foreground">
                  {profile?.status || "Medlem"}
                </span>
              </div>
              <button
                onClick={() => signOut()}
                title="Logga ut"
                className="rounded-md p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => signInWithDiscord()}
              className="hidden items-center gap-2 rounded-md bg-[#5865F2] px-3 py-2 text-sm font-semibold text-white sm:flex"
            >
              <MessageCircle className="h-4 w-4" /> Logga in med Discord
            </button>
          )}
        </header>

        <main className="flex-1 py-12">{children}</main>

        <footer className="glass mb-4 flex flex-wrap items-center justify-between gap-2 rounded-lg px-4 py-3 text-sm">
          <span className="text-muted-foreground">© 2026 {SITE_NAME}</span>
          <div className="flex gap-4">
            <a href="#">Integritetspolicy</a>
            <a href="#">Cookies</a>
            <a href={DISCORD_URL} className="flex items-center gap-1">
              <MessageCircle className="h-4 w-4" /> Discord
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  intro,
  back,
}: {
  eyebrow: string;
  title: string;
  intro?: string;
  back?: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      {back && <div className="mb-8 text-left text-sm text-muted-foreground">{back}</div>}
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
        {eyebrow}
      </p>
      <h1 className="text-glow mt-3 text-4xl font-bold">{title}</h1>
      {intro && <p className="mt-4 text-muted-foreground">{intro}</p>}
    </div>
  );
}

export function LoginPrompt() {
  const { user, loading, signInWithDiscord } = useAuth();
  if (loading || user) return null;
  return (
    <div className="glass mx-auto mt-10 max-w-xl rounded-lg px-4 py-5 text-center">
      <p className="text-sm text-muted-foreground">
        Du behöver vara inloggad med Discord för att skicka in ansökningar.
      </p>
      <button
        onClick={() => signInWithDiscord()}
        className="mt-4 inline-flex items-center gap-2 rounded-md bg-[#5865F2] px-5 py-2.5 text-sm font-semibold text-white"
      >
        <MessageCircle className="h-4 w-4" /> Logga in med Discord
      </button>
    </div>
  );
}

export function LoggedInBanner() {
  const { user, profile, loading } = useAuth();
  if (loading || !user) return null;
  const name =
    profile?.display_name ||
    profile?.discord_username ||
    user.user_metadata?.preferred_username ||
    "dig";
  return (
    <div className="glass mx-auto mt-10 max-w-xl rounded-lg px-4 py-4 text-center text-sm">
      Inloggad som <strong>{name}</strong>.{" "}
      <Link to="/portal" className="underline-offset-4 hover:underline">
        Visa mina ärenden
      </Link>
    </div>
  );
}
