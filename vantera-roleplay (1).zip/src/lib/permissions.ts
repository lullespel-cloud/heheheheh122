/**
 * Vantera Roleplay – roller & behörigheter
 *
 * Hierarki (högst → lägst):
 * ägare → delägare → head admin → admin → head mod → mod → helper
 * Special: medlemskapsansvarig, krimansvarig, donationsansvarig
 */

export type Role =
  | "ägare"
  | "delägare"
  | "head admin"
  | "admin"
  | "head mod"
  | "mod"
  | "helper"
  | "medlemskapsansvarig"
  | "krimansvarig"
  | "donationsansvarig"
  | "staff"
  | "medlem"
  | "kriminell"
  | "servervakt";

/** Ägare / delägare / head admin / admin – kan redigera regler, prislista, innehåll */
export const CONTENT_EDITORS: Role[] = ["ägare", "delägare", "head admin", "admin"];

/** Alla staff-nivåer (ser staff-meny, kan kolla banöverklaganden) */
export const STAFF_LEVEL: Role[] = [
  "ägare",
  "delägare",
  "head admin",
  "admin",
  "head mod",
  "mod",
  "helper",
  "medlemskapsansvarig",
  "krimansvarig",
  "donationsansvarig",
  "staff",
  "servervakt",
];

/** Får dokumentera ban / unban / donation / varning m.m. */
export const DOC_ROLES: Role[] = [
  "ägare",
  "delägare",
  "head admin",
  "admin",
  "head mod",
  "mod",
  "helper",
  "medlemskapsansvarig",
  "krimansvarig",
  "donationsansvarig",
  "staff",
  "servervakt",
];

/**
 * Vilka formulär varje roll får godkänna/neka.
 * Banöverklagan: ALLA staff-nivåer får se och svara.
 */
export const FORM_HANDLERS: Record<string, Role[]> = {
  // Endast medlemskapsansvarig + ledning
  medlemskap: [
    "medlemskapsansvarig",
    "head admin",
    "admin",
    "delägare",
    "ägare",
  ],

  // Krimansvarig + ledning
  kriminell: ["krimansvarig", "head admin", "admin", "delägare", "ägare"],

  // Staff-ansökan – head mod och uppåt
  staff: ["head mod", "mod", "head admin", "admin", "delägare", "ägare"],

  // Servervakt
  servervakt: ["head mod", "mod", "head admin", "admin", "delägare", "ägare", "servervakt"],

  // Medlemskapsansvarig-ansökan
  medlemskapsansvarig: ["head admin", "admin", "delägare", "ägare"],

  // Jobb
  jobb: ["head mod", "mod", "head admin", "admin", "delägare", "ägare"],

  // Banöverklagan – ALLA staff får kolla och svara
  banoverklagan: [
    "ägare",
    "delägare",
    "head admin",
    "admin",
    "head mod",
    "mod",
    "helper",
    "medlemskapsansvarig",
    "krimansvarig",
    "donationsansvarig",
    "staff",
    "servervakt",
  ],

  // Staffanmälan – bara högre ledning
  staffanmalan: ["head admin", "admin", "delägare", "ägare"],

  // Servervaktanmälan
  servervaktanmalan: [
    "head mod",
    "mod",
    "head admin",
    "admin",
    "delägare",
    "ägare",
    "servervakt",
  ],
};

export type DocType =
  | "ban"
  | "unban"
  | "donation"
  | "kick"
  | "warn"
  | "note"
  | "whitelist"
  | "other";

export const DOC_TYPE_LABELS: Record<DocType, string> = {
  ban: "Ban",
  unban: "Unban",
  donation: "Donation",
  kick: "Kick",
  warn: "Varning",
  note: "Anteckning",
  whitelist: "Whitelist",
  other: "Övrigt",
};

export function normalizeRoles(roles: string[] | null | undefined): string[] {
  return (roles ?? []).map((r) => r.toLowerCase().trim());
}

export function hasAnyRole(userRoles: string[] | null | undefined, allowed: Role[]): boolean {
  const lower = normalizeRoles(userRoles);
  return allowed.some((a) => lower.includes(a.toLowerCase()));
}

export function canHandleForm(userRoles: string[] | null | undefined, formSlug: string): boolean {
  const allowed = FORM_HANDLERS[formSlug];
  if (!allowed) {
    return hasAnyRole(userRoles, ["ägare", "delägare", "head admin", "admin"]);
  }
  return hasAnyRole(userRoles, allowed);
}

export function canDocument(userRoles: string[] | null | undefined): boolean {
  return hasAnyRole(userRoles, DOC_ROLES);
}

export function isStaffLevel(userRoles: string[] | null | undefined): boolean {
  return hasAnyRole(userRoles, STAFF_LEVEL);
}

export function canEditContent(userRoles: string[] | null | undefined): boolean {
  return hasAnyRole(userRoles, CONTENT_EDITORS);
}
