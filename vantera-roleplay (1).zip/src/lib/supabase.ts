import { createClient } from "@supabase/supabase-js";
import type { DocType } from "./permissions";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    "[Vantera] Saknar VITE_SUPABASE_URL eller VITE_SUPABASE_ANON_KEY. Skapa en .env-fil (se SETUP.md)."
  );
}

export const supabase = createClient(
  supabaseUrl || "https://placeholder.supabase.co",
  supabaseAnonKey || "placeholder"
);

export type Profile = {
  id: string;
  discord_id: string | null;
  discord_username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  roles: string[];
  status: string;
  created_at: string;
};

export type Application = {
  id: string;
  user_id: string;
  category: string;
  form_slug: string;
  title: string;
  data: Record<string, string>;
  status: "pending" | "approved" | "denied" | "closed";
  staff_note: string | null;
  handled_by: string | null;
  created_at: string;
  updated_at: string;
  profiles?: Profile | null;
};

export type StaffLog = {
  id: string;
  created_by: string;
  target_discord: string | null;
  target_name: string | null;
  doc_type: DocType;
  title: string;
  body: string;
  amount: number | null;
  created_at: string;
  profiles?: Profile | null;
};
