export const SITE_NAME = "Vantera Roleplay";
export const SHORT_NAME = "Vantera";
export const DISCORD_URL = "https://discord.gg/"; // Byt till din invite-länk

export type Form = {
  slug: string;
  title: string;
  desc: string;
  fields?: { id: string; label: string; type?: "text" | "textarea"; required?: boolean }[];
};

export const applicationCategories: Record<
  string,
  { label: string; title: string; intro: string; forms: Form[] }
> = {
  ansokningar: {
    label: "Ansökningar",
    title: "Välj formulär",
    intro: "Medlemskap, kriminell, servervakt, staff och mer.",
    forms: [
      {
        slug: "medlemskap",
        title: "Whitelist / medlemskap",
        desc: "Ansök om att få spela på Vantera Roleplay.",
        fields: [
          { id: "karaktarsnamn", label: "Karaktärsnamn", required: true },
          { id: "bakgrund", label: "Kort bakgrund", type: "textarea", required: true },
          { id: "erfarenhet", label: "Tidigare RP-erfarenhet", type: "textarea" },
        ],
      },
      {
        slug: "kriminell",
        title: "Kriminellansökan",
        desc: "Skapa genomtänkta kriminella berättelser.",
        fields: [
          { id: "rubrik", label: "Rubrik", required: true },
          { id: "inledning", label: "Inledning", type: "textarea", required: true },
          { id: "bakgrund", label: "Beskriv din kriminella karaktär och dess bakgrund", type: "textarea", required: true },
          { id: "rollspel", label: "Hur skapar du bra rollspel för motparten?", type: "textarea", required: true },
          { id: "regler", label: "Vilka krimregler är viktigast och varför?", type: "textarea", required: true },
        ],
      },
      {
        slug: "servervakt",
        title: "Servervaktsansökan",
        desc: "Ansök om att bli servervakt och hjälpa till med ordning på servern.",
        fields: [
          { id: "motivation", label: "Varför vill du bli servervakt?", type: "textarea", required: true },
          { id: "erfarenhet", label: "Tidigare erfarenhet", type: "textarea" },
        ],
      },
      {
        slug: "staff",
        title: "Staffansökan",
        desc: "Att vara staff på Vantera innebär att följa regler, samarbeta med teamet och vara aktiv när det behövs.",
        fields: [
          { id: "motivation", label: "Varför vill du bli staff?", type: "textarea", required: true },
          { id: "erfarenhet", label: "Tidigare staff-/moderator-erfarenhet", type: "textarea" },
          { id: "tillganglig", label: "Hur aktiv kan du vara?", type: "textarea", required: true },
        ],
      },
      {
        slug: "medlemskapsansvarig",
        title: "Ansökan om medlemskapsansvarig",
        desc: "Ansök om rollen medlemskapsansvarig.",
        fields: [
          { id: "motivation", label: "Varför vill du ha den här rollen?", type: "textarea", required: true },
        ],
      },
      {
        slug: "jobb",
        title: "Jobbansökan (chef)",
        desc: "Ansök om att bli chef inom ett yrke eller företag.",
        fields: [
          { id: "jobb", label: "Vilket jobb/företag?", required: true },
          { id: "motivation", label: "Varför just dig?", type: "textarea", required: true },
        ],
      },
    ],
  },
  serversupport: {
    label: "Serversupport",
    title: "Välj formulär",
    intro: "Anmälningar till staff och servervakt, samt banöverklagan.",
    forms: [
      {
        slug: "banoverklagan",
        title: "Banöverklagan",
        desc: "Be om en ny bedömning av din avstängning. Bara du och staff kan läsa ärendet.",
        fields: [
          { id: "anledning", label: "Varför bör banen omprövas?", type: "textarea", required: true },
          { id: "bevis", label: "Bevis / länkar", type: "textarea" },
        ],
      },
      {
        slug: "staffanmalan",
        title: "Staffanmälan",
        desc: "Anmäl missbruk av staff. Beskriv händelsen tydligt och bifoga länkar till bevis.",
        fields: [
          { id: "beskrivning", label: "Beskriv händelsen", type: "textarea", required: true },
          { id: "bevis", label: "Bevis / länkar", type: "textarea" },
        ],
      },
      {
        slug: "servervaktanmalan",
        title: "Servervaktanmälan",
        desc: "Anmäl problem eller situationer som servervaktsansvarig bör ta del av.",
        fields: [
          { id: "beskrivning", label: "Beskriv problemet", type: "textarea", required: true },
        ],
      },
    ],
  },
};

export type PriceTable = { title: string; cols: string[]; rows: string[][] };
export type Thread = { slug: string; title: string; meta: string; body: string[] | null; prices?: PriceTable[] };

const sek = ["Föremål / tjänst", "Pris"];
const both = ["Föremål / tjänst", "Pris i spelet", "Pris i SEK"];

export const priceTables: PriceTable[] = [
  {
    title: "Specifika föremål",
    cols: sek,
    rows: [
      ["Kriminell roll", "150 kr"],
      ["Kriminell roll (om du blivit av med den)", "200 kr"],
      ["Kriminell roll (fuskökning)", "500 kr"],
      ["Krim case", "100 kr / st"],
      ["Privatinköp", "1 500 kr"],
      ["Dubbelarbetare", "300 kr"],
    ],
  },
  {
    title: "Bilrelaterade priser",
    cols: sek,
    rows: [
      ["Ej inlagt importfordon", "500 kr (max 30 MB)"],
      ["Inlagt importfordon", "Se importbilar-kanalen"],
      ["Patent till fordon", "200 kr"],
      ["Importöverföring", "200 kr"],
      ["Inlagt billjud", "150 kr"],
      ["Ej inlagt billjud", "300 kr"],
      ["Bilfirma bil", "150 kr"],
    ],
  },
  {
    title: "Pedrelaterade priser",
    cols: sek,
    rows: [
      ["PED", "500 kr (max 30 MB)"],
      ["PED-byte (en som finns in-game)", "150 kr"],
      ["PED-byte (ny modell)", "200 kr (max 30 MB)"],
      ["Extra plats för delad PED", "100 kr"],
      ["Specialgångstil", "200 kr"],
    ],
  },
  {
    title: "Gängrelaterade priser",
    cols: sek,
    rows: [
      ["Gäng", "Kolla lediga gäng"],
      ["Lagning", "200 kr"],
      ["Inlagt icke-importfordon till gäng", "100 kr"],
      ["Byte av färg på fordon till gäng", "100 kr"],
      ["Namnbyte på gäng", "100 kr"],
      ["Importerat gänghus (ej in-game)", "750 kr"],
      ["Byte av gänghus (in-game)", "150 kr"],
      ["Helikopter till gäng", "800 kr"],
      ["Båtar till gäng", "250 kr"],
    ],
  },
  {
    title: "Specifika inköp till gäng i FiveM",
    cols: both,
    rows: [
      ["AK-47", "500 000 kr", "400 kr"],
      ["SCAR-H", "500 000 kr", "400 kr"],
      ["UZI", "500 000 kr", "500 kr"],
      ["TAURUS", "200 000 kr", "300 kr"],
      ["RUST AK", "550 000 kr", "800 kr"],
      ["GLOCK 19", "350 000 kr", "300 kr"],
      ["AUG", "500 000 kr", "350 kr"],
      ["P90", "500 000 kr", "350 kr"],
      ["GLOCK 17", "600 000 kr", "550 kr"],
      ["DEAGLE", "500 000 kr", "400 kr"],
      ["MP45", "500 000 kr", "500 kr"],
      ["GLOCK 18C", "550 000 kr", "350 kr"],
      ["G17C", "500 000 kr", "500 kr"],
      ["MP7", "550 000 kr", "550 kr"],
      ["DRACO", "500 000 kr", "500 kr"],
      ["SPECIALINKÖP (GTA-VAPEN, IN-GAME)", "500 000 kr", "600 kr"],
      ["SPECIALINKÖP (EJ IN-GAME)", "600 000 kr", "900 kr"],
      ["SPECIALINKÖP (FINNS IN-GAME)", "550 000 kr", "Beroende på vapen"],
    ],
  },
  {
    title: "Tillägg & tillbehör",
    cols: both,
    rows: [
      ["LJUDDÄMPARE", "75 000 kr", "200 kr"],
      ["GREPP", "65 000 kr", "200 kr"],
      ["DRUM MAG / EXTENDED CLIP", "75 000 kr", "200 kr"],
      ["SKOTTLÅDA", "20 000 kr", "150 kr"],
    ],
  },
];

export const informationCategories: Record<
  string,
  { label: string; title: string; intro: string; threads: Thread[] }
> = {
  regler: {
    label: "Regler",
    title: "Trådar",
    intro: "Server-, Discord- och rollspelsregler.",
    threads: [
      { slug: "fivem", title: "FiveM-servern | (Sek. 1)", meta: "Regler", body: null },
      { slug: "discord", title: "Discordservern | (Sek. 2)", meta: "Regler", body: null },
      { slug: "kriminell", title: "Kriminell | (Sek. 3)", meta: "Regler", body: null },
      { slug: "community", title: "Community | (Sek. 4)", meta: "Regler", body: null },
      { slug: "gang", title: "Gäng | (Sek. 5)", meta: "Regler", body: null },
      { slug: "forum", title: "Forum | (Sek. 6)", meta: "Regler", body: null },
    ],
  },
  information: {
    label: "Information",
    title: "Trådar",
    intro: "Praktisk information och tillägg.",
    threads: [
      {
        slug: "kopvillkor",
        title: "Köpvillkor",
        meta: "Information · Uppdaterad 18 november 2026",
        body: [
          "Innan du överväger att göra en donation eller genomföra ett köp hos oss, ber vi dig att noggrant läsa igenom våra köpvillkor. Dessa villkor innehåller viktig information om dina rättigheter och skyldigheter samt våra policyer kring betalning och återbetalning.",
          "Genom att fortsätta med en donation eller ett köp, förutsätter vi att du har läst, förstått och godkänt dessa villkor i sin helhet.",
          "Om du har några frågor eller behöver ytterligare förtydliganden är du alltid välkommen att kontakta oss genom en lednings-ticket innan du slutför din transaktion.",
        ],
      },
      {
        slug: "prislista",
        title: "Prislista",
        meta: "Information · Donationer och tillval",
        body: null,
        prices: priceTables,
      },
    ],
  },
};

/** Staff-roller som ger behörighet att hantera ansökningar */
export const STAFF_ROLES = [
  "staff",
  "admin",
  "ägare",
  "owner",
  "medlemskapsansvarig",
  "servervakt",
  "ledning",
] as const;
