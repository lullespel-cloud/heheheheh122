import { createFileRoute, Link } from "@tanstack/react-router";
import { MessageSquare } from "lucide-react";
import { Layout, PageHeader } from "@/components/Layout";
import { infoCategories, SITE_NAME, SHORT_NAME } from "@/lib/site";

export const Route = createFileRoute("/information/")({
  head: () => ({
    meta: [
      { title: `Regler & information – ${SITE_NAME}` },
      { name: "description", content: "Server-, Discord- och rollspelsregler samt praktisk information." },
      { property: "og:title", content: `Regler & information – ${SITE_NAME}` },
      { property: "og:description", content: "Server-, Discord- och rollspelsregler samt praktisk information." },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <Layout>
      <PageHeader eyebrow="Information" title="Regler & information" intro="Välj en kategori för att se trådar och läsa fullständiga texter." />
      <div className="mx-auto mt-12 grid max-w-4xl gap-5 md:grid-cols-2">
        {Object.entries(infoCategories).map(([k, c]) => (
          <Link key={k} to="/information/$kategori" params={{ kategori: k }} className="glass flex gap-4 rounded-lg p-5 transition-transform hover:-translate-y-1">
            <div className="h-fit rounded-md bg-secondary p-2.5"><MessageSquare className="h-5 w-5" /></div>
            <div><h2 className="text-xl font-bold">{c.label}</h2><p className="mt-1 text-sm text-muted-foreground">{c.intro}</p></div>
          </Link>
        ))}
      </div>
      <p className="mt-8 text-center text-sm text-muted-foreground">✧ Uppdateringar från {SHORT_NAME} →</p>
    </Layout>
  );
}
