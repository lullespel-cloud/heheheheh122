import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Layout, PageHeader, LoginPrompt } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { supabase, type Application } from "@/lib/supabase";
import { SITE_NAME } from "@/lib/site";
import { FileText, History, Settings, Shield, User } from "lucide-react";

export const Route = createFileRoute("/portal")({
  head: () => ({
    meta: [{ title: `Min portal – ${SITE_NAME}` }],
  }),
  component: PortalPage,
});

function PortalPage() {
  const { user, profile, loading, isStaff, signInWithDiscord, signOut } = useAuth();
  const [apps, setApps] = useState<Application[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("applications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => setApps((data as Application[]) ?? []));
  }, [user]);

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout>
        <PageHeader
          eyebrow="Min portal"
          title="Logga in"
          intro="Logga in med Discord för att se din portal, ansökningar och status."
        />
        <LoginPrompt />
      </Layout>
    );
  }

  const displayName =
    profile?.display_name ||
    profile?.discord_username ||
    user.user_metadata?.preferred_username ||
    "Användare";

  return (
    <Layout>
      <PageHeader
        eyebrow="Min portal"
        title="Översikt"
        intro="Allt som rör ditt konto på Vantera, samlat på ett ställe."
      />

      <div className="mx-auto mt-10 max-w-3xl space-y-6">
        <div className="glass rounded-lg p-5">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-xl font-bold">
              {displayName.slice(0, 1).toUpperCase()}
            </div>
            <div>
              <h2 className="text-xl font-bold">{displayName}</h2>
              <p className="text-sm text-muted-foreground">
                Status: {profile?.status || "Medlem"}
                {isStaff && " · Staff"}
              </p>
            </div>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Link to="/ansokningar" className="glass flex gap-3 rounded-lg p-4 hover:bg-accent/50">
            <FileText className="h-5 w-5 shrink-0" />
            <div>
              <div className="font-semibold">Mina ansökningar</div>
              <div className="text-sm text-muted-foreground">
                {apps.length === 0 ? "Inga ansökningar ännu" : `${apps.length} st`}
              </div>
            </div>
          </Link>

          {isStaff && (
            <Link to="/staff" className="glass flex gap-3 rounded-lg p-4 hover:bg-accent/50">
              <Shield className="h-5 w-5 shrink-0" />
              <div>
                <div className="font-semibold">Staff-panel</div>
                <div className="text-sm text-muted-foreground">Hantera inkomna ärenden</div>
              </div>
            </Link>
          )}
        </div>

        {apps.length > 0 && (
          <div className="glass rounded-lg p-5">
            <h3 className="mb-4 font-bold">Senaste ansökningar</h3>
            <ul className="space-y-3">
              {apps.slice(0, 10).map((a) => (
                <li key={a.id} className="flex items-center justify-between text-sm">
                  <span>{a.title}</span>
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      a.status === "pending"
                        ? "bg-amber-500/20 text-amber-200"
                        : a.status === "approved"
                          ? "bg-emerald-500/20 text-emerald-200"
                          : "bg-red-500/20 text-red-200"
                    }`}
                  >
                    {a.status === "pending" ? "Väntar" : a.status === "approved" ? "Godkänd" : "Nekad"}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <button
          onClick={() => signOut()}
          className="text-sm text-muted-foreground underline-offset-4 hover:underline"
        >
          Logga ut
        </button>
      </div>
    </Layout>
  );
}
