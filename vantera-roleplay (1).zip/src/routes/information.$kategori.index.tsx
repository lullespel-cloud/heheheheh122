import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { FileText } from "lucide-react";
import { Layout, PageHeader } from "@/components/Layout";
import { infoCategories, SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/information/$kategori/")({
  loader: ({ params }) => {
    const cat = infoCategories[params.kategori];
    if (!cat) throw notFound();
    return cat;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.label ?? "Trådar"} – ${SITE_NAME}` },
      { name: "description", content: loaderData?.intro ?? "" },
      { property: "og:title", content: `${loaderData?.label ?? "Trådar"} – ${SITE_NAME}` },
      { property: "og:description", content: loaderData?.intro ?? "" },
    ],
  }),
  component: Page,
});

function Page() {
  const cat = Route.useLoaderData();
  const { kategori } = Route.useParams();
  return (
    <Layout>
      <PageHeader eyebrow={cat.label} title="Trådar" intro={cat.intro} back={<Link to="/information">← Information</Link>} />
      <div className="mx-auto mt-12 grid max-w-4xl gap-5 md:grid-cols-2">
        {cat.threads.map((t) => (
          <Link key={t.slug} to="/information/$kategori/$slug" params={{ kategori, slug: t.slug }} className="glass rounded-lg p-5 transition-transform hover:-translate-y-1">
            <div className="w-fit rounded-md bg-secondary p-2.5"><FileText className="h-5 w-5" /></div>
            <h2 className="mt-4 text-lg font-bold">{t.title}</h2>
            <span className="mt-2 inline-block rounded-md border bg-badge px-2 py-0.5 text-xs font-semibold text-badge-foreground">{cat.label}</span>
            <div className="mt-4 border-t pt-4 text-sm text-muted-foreground">{t.meta}</div>
          </Link>
        ))}
      </div>
    </Layout>
  );
}
