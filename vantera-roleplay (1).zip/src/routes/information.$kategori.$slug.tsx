import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Layout } from "@/components/Layout";
import { infoCategories, SITE_NAME } from "@/lib/site";

export const Route = createFileRoute("/information/$kategori/$slug")({
  loader: ({ params }) => {
    const cat = infoCategories[params.kategori];
    const thread = cat?.threads.find((t) => t.slug === params.slug);
    if (!cat || !thread) throw notFound();
    return { label: cat.label, thread };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.thread.title ?? "Tråd"} – ${SITE_NAME}` },
      { name: "description", content: `${loaderData?.thread.title ?? ""} hos ${SITE_NAME}.` },
      { property: "og:title", content: `${loaderData?.thread.title ?? "Tråd"} – ${SITE_NAME}` },
      { property: "og:description", content: `${loaderData?.thread.title ?? ""} hos ${SITE_NAME}.` },
    ],
  }),
  component: Page,
});

function Page() {
  const { label, thread } = Route.useLoaderData();
  const { kategori } = Route.useParams();
  return (
    <Layout>
      <div className="mx-auto max-w-4xl">
        <Link to="/information/$kategori" params={{ kategori }} className="text-sm text-muted-foreground">← {label}</Link>
        <h1 className="text-glow mt-10 text-3xl font-bold">{thread.title}</h1>
        <span className="mt-3 inline-block rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{label}</span>
        <p className="mt-4 border-b pb-6 text-sm text-muted-foreground">{thread.meta}</p>
        <article className="glass mt-8 space-y-4 rounded-lg p-8 leading-relaxed md:p-12">
          {thread.prices && (
            <div className="rounded-lg border bg-secondary/40 p-4 text-sm">
              <span className="font-bold">Betalning</span> <span className="text-muted-foreground">Swish och PayPal</span>
              <div><Link to="/information/$kategori/$slug" params={{ kategori: "information", slug: "kopvillkor" }} className="underline">Läs köpvillkoren före köp.</Link></div>
            </div>
          )}
          {thread.body ? thread.body.map((p, i) => <p key={i} className={thread.prices ? "text-muted-foreground" : ""}>{p}</p>) : <p className="text-muted-foreground">Innehållet är ännu inte publicerat.</p>}
          {thread.prices?.map((t) => (
            <section key={t.title} className="pt-2">
              <h2 className="mb-2 inline-block rounded-md border bg-secondary px-2 py-0.5 text-sm font-bold">{t.title}</h2>
              <div className="overflow-x-auto rounded-lg border">
                <table className="w-full text-xs">
                  <thead><tr className="border-b">{t.cols.map((c, i) => <th key={c} className={`px-3 py-3 font-semibold uppercase tracking-widest text-muted-foreground ${i === 0 ? "text-left" : "text-right"}`}>{c}</th>)}</tr></thead>
                  <tbody>{t.rows.map((r) => <tr key={r[0]} className="border-b last:border-0">{r.map((c, i) => <td key={i} className={`px-3 py-3 ${i === 0 ? "font-semibold uppercase tracking-wider" : "text-right"} ${i === 1 && r.length === 3 ? "text-sm font-semibold" : ""}`}>{c}</td>)}</tr>)}</tbody>
                </table>
              </div>
            </section>
          ))}
          {thread.prices && <p className="text-sm text-muted-foreground">Priser och villkor kan uppdateras.</p>}
        </article>
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <Link to="/information/$kategori" params={{ kategori }}>← Tillbaka till {label.toLowerCase()}</Link>
        </div>
      </div>
    </Layout>
  );
}
