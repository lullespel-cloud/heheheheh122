import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { FileText } from "lucide-react";
import { Layout, PageHeader, LoggedInBanner, LoginPrompt } from "@/components/Layout";
import { applicationCategories, SITE_NAME } from "@/lib/site";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/ansokningar/$kategori")({
  loader: ({ params }) => {
    const cat = applicationCategories[params.kategori];
    if (!cat) throw notFound();
    return cat;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.label ?? "Formulär"} – ${SITE_NAME}` },
      { name: "description", content: loaderData?.intro ?? "" },
    ],
  }),
  component: Page,
});

function Page() {
  const cat = Route.useLoaderData();
  const params = Route.useParams();
  const { user } = useAuth();

  return (
    <Layout>
      <PageHeader
        eyebrow={cat.label}
        title={cat.title}
        intro={cat.intro}
        back={<Link to="/ansokningar">← Ansökningar</Link>}
      />
      {user ? <LoggedInBanner /> : <LoginPrompt />}
      <div className="mt-12 grid gap-5 md:grid-cols-3">
        {cat.forms.map((f) => (
          <Link
            key={f.slug}
            to="/ansokningar/$kategori/$slug"
            params={{ kategori: params.kategori, slug: f.slug }}
            className="glass flex flex-col rounded-lg p-5 transition-transform hover:-translate-y-1"
          >
            <div className="w-fit rounded-md bg-secondary p-2.5">
              <FileText className="h-5 w-5" />
            </div>
            <h2 className="mt-4 text-lg font-bold">{f.title}</h2>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">{f.desc}</p>
            <div className="mt-4 border-t pt-4 text-sm">Öppna formulär →</div>
          </Link>
        ))}
      </div>
    </Layout>
  );
}
