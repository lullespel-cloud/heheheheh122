import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Layout, PageHeader, LoginPrompt } from "@/components/Layout";
import { applicationCategories, SITE_NAME } from "@/lib/site";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/ansokningar/$kategori/$slug")({
  loader: ({ params }) => {
    const cat = applicationCategories[params.kategori];
    if (!cat) throw notFound();
    const form = cat.forms.find((f) => f.slug === params.slug);
    if (!form) throw notFound();
    return { cat, form };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.form.title ?? "Formulär"} – ${SITE_NAME}` },
      { name: "description", content: loaderData?.form.desc ?? "" },
    ],
  }),
  component: FormPage,
});

function FormPage() {
  const { cat, form } = Route.useLoaderData();
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const fields = form.fields ?? [
    { id: "meddelande", label: "Meddelande", type: "textarea" as const, required: true },
  ];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    setError(null);

    const { error: insertError } = await supabase.from("applications").insert({
      user_id: user.id,
      category: cat.label,
      form_slug: form.slug,
      title: form.title,
      data: values,
      status: "pending",
    });

    setSubmitting(false);
    if (insertError) {
      setError(insertError.message);
      return;
    }
    setDone(true);
    setTimeout(() => navigate({ to: "/portal" }), 1500);
  }

  if (done) {
    return (
      <Layout>
        <PageHeader eyebrow={cat.label} title="Skickat!" intro="Din ansökan har sparats. Du skickas till Min portal." />
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader
        eyebrow={cat.label}
        title={form.title}
        intro={form.desc}
        back={<Link to="/ansokningar/$kategori" params={{ kategori: Object.keys(applicationCategories).find((k) => applicationCategories[k] === cat)! }}>← Tillbaka</Link>}
      />

      {!loading && !user && <LoginPrompt />}

      {user && (
        <form onSubmit={handleSubmit} className="glass mx-auto mt-10 max-w-2xl space-y-6 rounded-lg p-6">
          <div className="rounded-md bg-secondary/50 px-4 py-3 text-sm">
            Skickas som{" "}
            <strong>
              {profile?.discord_username ||
                user.user_metadata?.preferred_username ||
                user.email}
            </strong>
          </div>

          {fields.map((f) => (
            <div key={f.id}>
              <label className="mb-1.5 block text-sm font-medium">
                {f.label}
                {f.required && <span className="text-red-400"> *</span>}
              </label>
              {f.type === "textarea" ? (
                <textarea
                  required={f.required}
                  rows={4}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={values[f.id] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.id]: e.target.value }))}
                />
              ) : (
                <input
                  type="text"
                  required={f.required}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={values[f.id] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [f.id]: e.target.value }))}
                />
              )}
            </div>
          ))}

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-md bg-primary px-5 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
          >
            {submitting ? "Skickar…" : "Skicka in"}
          </button>
        </form>
      )}
    </Layout>
  );
}
