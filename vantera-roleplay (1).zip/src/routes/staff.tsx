import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Layout, PageHeader } from "@/components/Layout";
import { useAuth } from "@/lib/auth";
import { supabase, type Application } from "@/lib/supabase";
import { SITE_NAME } from "@/lib/site";
import { BookOpen } from "lucide-react";

export const Route = createFileRoute("/staff")({
  head: () => ({
    meta: [{ title: `Staff-panel – ${SITE_NAME}` }],
  }),
  component: StaffPage,
});

function StaffPage() {
  const { user, isStaff, canHandle, loading } = useAuth();
  const [apps, setApps] = useState<Application[]>([]);
  const [filter, setFilter] = useState<"pending" | "approved" | "denied" | "all">("pending");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [note, setNote] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!user || !isStaff) return;
    load();
  }, [user, isStaff, filter]);

  async function load() {
    let q = supabase
      .from("applications")
      .select("*, profiles(*)")
      .order("created_at", { ascending: false });

    if (filter !== "all") q = q.eq("status", filter);

    const { data, error } = await q;
    if (error) {
      console.error(error);
      return;
    }
    // Filtrera så användaren bara ser ärenden hen får hantera
    const all = (data as Application[]) ?? [];
    setApps(all.filter((a) => canHandle(a.form_slug)));
  }

  async function setStatus(id: string, status: "approved" | "denied", formSlug: string) {
    if (!user) return;
    if (!canHandle(formSlug)) {
      alert("Du har inte behörighet att hantera den här typen av ansökan.");
      return;
    }
    setBusyId(id);
    const { error } = await supabase
      .from("applications")
      .update({
        status,
        staff_note: note[id] || null,
        handled_by: user.id,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id);

    setBusyId(null);
    if (error) {
      alert("Kunde inte uppdatera: " + error.message);
      return;
    }
    load();
  }

  if (loading) {
    return (
      <Layout>
        <p className="text-center text-muted-foreground">Laddar…</p>
      </Layout>
    );
  }

  if (!user || !isStaff) {
    return (
      <Layout>
        <PageHeader
          eyebrow="Staff"
          title="Ingen behörighet"
          intro="Du måste vara inloggad och ha en staff-roll för att se den här sidan."
        />
        <div className="mt-8 text-center">
          <Link to="/portal" className="underline">
            Tillbaka till portalen
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader
        eyebrow="Staff"
        title="Hantera ansökningar"
        intro="Du ser bara ärenden som din roll får hantera. Medlemskapsansvarig ser t.ex. bara medlemsansökningar."
      />

      <div className="mx-auto mt-4 flex max-w-4xl justify-end">
        <Link
          to="/staff/dokumentation"
          className="inline-flex items-center gap-2 rounded-md border border-violet-500/40 bg-violet-500/10 px-3 py-2 text-sm font-semibold text-violet-200"
        >
          <BookOpen className="h-4 w-4" /> Dokumentation (ban / donation m.m.)
        </Link>
      </div>

      <div className="mx-auto mt-6 flex max-w-4xl gap-2">
        {(["pending", "approved", "denied", "all"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-md px-3 py-1.5 text-sm font-medium ${
              filter === f ? "bg-primary text-primary-foreground" : "bg-secondary"
            }`}
          >
            {f === "pending" ? "Väntande" : f === "approved" ? "Godkända" : f === "denied" ? "Nekade" : "Alla"}
          </button>
        ))}
      </div>

      <div className="mx-auto mt-6 max-w-4xl space-y-4">
        {apps.length === 0 && (
          <p className="text-center text-muted-foreground">
            Inga ansökningar som du har behörighet att se i den här listan.
          </p>
        )}

        {apps.map((app) => (
          <div key={app.id} className="glass rounded-lg p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h3 className="font-bold">{app.title}</h3>
                <p className="text-xs text-muted-foreground">
                  {app.category} · {app.form_slug} ·{" "}
                  {new Date(app.created_at).toLocaleString("sv-SE")}
                  {app.profiles?.discord_username && <> · @{app.profiles.discord_username}</>}
                </p>
              </div>
              <span
                className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                  app.status === "pending"
                    ? "bg-amber-500/20 text-amber-200"
                    : app.status === "approved"
                      ? "bg-emerald-500/20 text-emerald-200"
                      : "bg-red-500/20 text-red-200"
                }`}
              >
                {app.status === "pending"
                  ? "Väntar"
                  : app.status === "approved"
                    ? "Godkänd"
                    : "Nekad"}
              </span>
            </div>

            <dl className="mt-4 space-y-2 text-sm">
              {Object.entries(app.data || {}).map(([k, v]) => (
                <div key={k}>
                  <dt className="font-medium text-muted-foreground">{k}</dt>
                  <dd className="whitespace-pre-wrap">{v}</dd>
                </div>
              ))}
            </dl>

            {app.status === "pending" && canHandle(app.form_slug) && (
              <div className="mt-4 space-y-3 border-t border-border pt-4">
                <textarea
                  placeholder="Intern anteckning (valfritt)"
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  rows={2}
                  value={note[app.id] ?? ""}
                  onChange={(e) => setNote((n) => ({ ...n, [app.id]: e.target.value }))}
                />
                <div className="flex gap-2">
                  <button
                    disabled={busyId === app.id}
                    onClick={() => setStatus(app.id, "approved", app.form_slug)}
                    className="rounded-md bg-emerald-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
                  >
                    Godkänn
                  </button>
                  <button
                    disabled={busyId === app.id}
                    onClick={() => setStatus(app.id, "denied", app.form_slug)}
                    className="rounded-md bg-red-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
                  >
                    Neka
                  </button>
                </div>
              </div>
            )}

            {app.staff_note && (
              <p className="mt-3 text-sm text-muted-foreground">Staff-anteckning: {app.staff_note}</p>
            )}
          </div>
        ))}
      </div>
    </Layout>
  );
}
